def test_intersect_intervals_standard():
    assert intersect_intervals(1, 5, 3, 7) == (3, 5)
    assert intersect_intervals(1, 5, 6, 7) is None
    assert intersect_intervals(1, 5, 0, 3) == (1, 3)

def test_intersect_intervals_unbounded():
    assert intersect_intervals(1, None, 3, 7) == (3, 7)
    assert intersect_intervals(None, 5, 3, 7) == (3, 5)
    assert intersect_intervals(None, None, 3, 7) == (3, 7)

def test_intersect_intervals_edge_cases():
    assert intersect_intervals(1, 1, 1, 1) == (1, 1)
    assert intersect_intervals(1, 1, 2, 2) is None
    assert intersect_intervals(None, None, None, None) == (None, None)

def test_intersect_intervals_invalid_inputs():
    try:
        intersect_intervals('a', 5, 3, 7)
        assert False, "Expected TypeError"
    except TypeError:
        pass

    try:
        intersect_intervals(1, 'b', 3, 7)
        assert False, "Expected TypeError"
    except TypeError:
        pass

    try:
        intersect_intervals(1, 5, 'c', 7)
        assert False, "Expected TypeError"
    except TypeError:
        pass

    try:
        intersect_intervals(1, 5, 3, 'd')
        assert False, "Expected TypeError"
    except TypeError:
        pass