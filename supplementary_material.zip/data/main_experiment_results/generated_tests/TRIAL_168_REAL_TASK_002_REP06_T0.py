from typing import List

def test_split_by_positions_standard_input():
    line = "  Hello  World  "
    positions = [2, 8]
    expected_output = ["Hello", "World"]
    assert split_by_positions(line, positions) == expected_output

def test_split_by_positions_empty_input():
    line = ""
    positions = []
    expected_output = []
    assert split_by_positions(line, positions) == expected_output

def test_split_by_positions_empty_positions():
    line = "Hello World"
    positions = []
    expected_output = []
    assert split_by_positions(line, positions) == expected_output

def test_split_by_positions_out_of_bounds_positions():
    line = "Hello World"
    positions = [10, 20]
    expected_output = ["Hello World"]
    assert split_by_positions(line, positions) == expected_output

def test_split_by_positions_negative_positions():
    line = "Hello World"
    positions = [-1, 5]
    try:
        split_by_positions(line, positions)
        assert False, "Expected ValueError for negative positions"
    except ValueError:
        pass

def test_split_by_positions_non_integer_positions():
    line = "Hello World"
    positions = [1.5, 5]
    try:
        split_by_positions(line, positions)
        assert False, "Expected TypeError for non-integer positions"
    except TypeError:
        pass