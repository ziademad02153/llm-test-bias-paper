# Test standard overlapping intervals
def test_standard_overlap():
    assert check_half_open_overlap(1, 5, 3, 7) == True

# Test non-overlapping intervals
def test_no_overlap():
    assert check_half_open_overlap(1, 3, 4, 7) == False

# Test edge case where intervals touch but do not overlap
def test_touching_intervals():
    assert check_half_open_overlap(1, 3, 3, 7) == False

# Test edge case where one interval is completely contained within the other
def test_contained_intervals():
    assert check_half_open_overlap(1, 7, 2, 6) == True

# Test edge case where intervals have the same start and end points
def test_same_intervals():
    assert check_half_open_overlap(1, 5, 1, 5) == True

# Test invalid input (negative numbers)
def test_invalid_input():
    try:
        check_half_open_overlap(-1, 5, 1, 7)
        assert False, "Expected an error for invalid input"
    except ValueError:
        pass