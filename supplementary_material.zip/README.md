# Replication Package: Disentangling Code Exposure from Model Diversity in Automated LLM Test Generation

This replication package contains all empirical artifacts, benchmark tasks, raw evaluation datasets, all 900 generated unit test suites, and statistical analysis scripts for the paper:
**"Disentangling Code Exposure from Model Diversity in Automated LLM Test Generation: A 2x2 Factorial Empirical Study"**
Author: **Ziad Emad Allam** (*Independent Researcher, Benha, Egypt*)
Target Journal: *Information and Software Technology (Elsevier)*
Repository: [https://github.com/ziademad02153/llm-test-bias-paper](https://github.com/ziademad02153/llm-test-bias-paper)

---

## Directory Structure

```text
├── README.md                           # Replication and execution guide
├── data/
│   ├── TASK_PROVENANCE_AND_LICENSES.md # Comprehensive provenance, commit hashes, and licenses
│   ├── main_experiment_results/
│   │   ├── main_glmm_dataset.csv       # Complete 900-row evaluation dataset (225 quadruplets)
│   │   ├── MAIN_EXPERIMENT_REPORT.md   # Statistical synthesis and exact test results
│   │   ├── GLMM_OUTPUT.txt             # Full R lme4 model printout and session info
│   │   ├── GLMM_COEFFICIENTS.csv       # Parameter estimates, SE, z, p-values, odds ratios
│   │   ├── GLMM_DIAGNOSTICS.csv        # Convergence diagnostics and likelihood-ratio test
│   │   ├── PROBLEM_LEVEL_SENSITIVITY.csv # Aggregated problem-level sensitivity contrasts
│   │   └── generated_tests/            # ALL 900 standalone generated unit test suites (*.py)
│   │       ├── TRIAL_001_REAL_TASK_001_REP01_T0.py
│   │       └── ... (900 Python files total: 225 trials x 4 conditions)
│   ├── fault_harvest/
│   │   ├── accepted_faults.json        # Ground-truth 15 natural logic defects with golden tests
│   │   ├── FAULT_HARVEST_REPORT.md     # Defect harvesting criteria and kill ratios
│   │   └── fault_candidates_log.csv    # Complete candidate generation log across temperatures
│   └── problems/                       # 15 standalone task specifications and reference solutions
│       ├── REAL_TASK_001.json
│       └── ...
├── src/
│   ├── evaluator.py                    # AST sanitization, test case slicing, reference execution
│   ├── runner.py                       # LLM orchestration and prompt formatting
│   ├── sandbox.py                      # Ephemeral Docker subprocess execution sandbox
│   ├── schema.py                       # Experimental conditions and data classes
│   └── stats_utils.py                  # McNemar exact tests and TOST equivalence analysis
└── scripts/
    ├── fit_interaction_glmm.R          # R script to fit primary GLMM and sensitivity models
    └── run_main_experiment.py          # Python test generation orchestrator
```

---

## Benchmark Tasks & Licensing Summary

The 15 evaluated benchmark tasks originated from public open-source software repositories on GitHub:
* **MIT Licensed (8 tasks):** `REAL_TASK_001`, `002`, `013`, `014`, `015`, `016`, `017`, `018` from repositories including `nothing-less`, `backon`, `mighty-security`, `calgebra`, and `ratelink`.
* **GPL-3.0 Licensed (1 task):** `REAL_TASK_005` from `ConfigForge-V2Ray`.
* **Public Open-Source (6 tasks):** `REAL_TASK_004`, `006`, `010`, `011`, `019`, `020` from public GitHub repositories (`tbench-agentic-data-pipeline`, `EV-charging-Allocation-System_Python`, `Alpha-Park`).

Full commit hashes, authors, and dates are documented in `data/TASK_PROVENANCE_AND_LICENSES.md`.

---

## Reproducing the Statistical Analysis (R & `lme4`)

The primary Generalized Linear Mixed Model (GLMM) and sensitivity analyses can be replicated directly using R:

### Prerequisites
* R (>= 4.3.0)
* Package `lme4` (>= 1.1-35)

### Execution Command
```bash
Rscript scripts/fit_interaction_glmm.R data/main_experiment_results/main_glmm_dataset.csv
```

This reproduces:
1. The protocol GLMM: `detected ~ exposure * cross_model + coder + (1 | problem_id)` with adaptive Gauss-Hermite quadrature ($nAGQ=9$).
2. The Likelihood-Ratio Test against the additive model.
3. The problem-level aggregated sensitivity analysis across 15 problem clusters ($N=15, \text{df}=14$).
4. The random-slopes exploratory model.

---

## Evaluating Test Suites in Isolated Docker Sandboxes

All 900 generated test suites in `data/main_experiment_results/generated_tests/` can be independently evaluated against reference and faulty implementations using Docker:

```bash
docker run --rm -v "$(pwd):/work" -w /work python:3.11-slim python -c "
import json
from pathlib import Path
from src.evaluator import evaluate_generated_test

problems = {p.stem: json.loads(p.read_text()) for p in Path('data/problems').glob('*.json')}
faults = json.loads(Path('data/fault_harvest/accepted_faults.json').read_text())

# Example evaluation of a single trial suite:
test_code = Path('data/main_experiment_results/generated_tests/TRIAL_001_REAL_TASK_001_REP01_T0.py').read_text()
res = evaluate_generated_test(
    problem_spec=problems['REAL_TASK_001'],
    faulty_candidate=faults['REAL_TASK_001'],
    generated_test_code=test_code,
    timeout_seconds=6.0
)
print('Evaluation result:', res)
"
```
